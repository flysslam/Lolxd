const credits = `
Credits:
- Sempiller

>>> Special thanks to Snek aka Mr. Bumpkin
`;

console.log(credits);